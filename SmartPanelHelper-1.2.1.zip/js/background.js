chrome.webNavigation.onHistoryStateUpdated.addListener(function(details) {
    if(details.url.startsWith('https://global-aiworks.smartpanel.kr/worklist2')) {
        chrome.storage.sync.set({isNavigate: true});
    }
    else if(details.url.startsWith('https://global-aiworks.smartpanel.kr/work?projectID=')) {
        chrome.scripting.executeScript({
            target: { tabId: details.tabId },
            files: [
                'third-party/jquery-3.6.0.slim.min.js',
                'js/label-work.min.js'
            ],
        });
    }
});