(function() {

    const SaveInterval = 60 * 5;
    const KEYCODE_1 = 49;

    function loadWork() {
        setTimeout(function() {
            if(isReady()) {
                // 화면 초기화
                initPanel();

                // 단축키 설정
                setShortKey();

                // 중간 저장 타이머 설정
                setKeepSaveTimer();

                // 중간 저장 클릭 이벤트 핸들러
                setKeepSaveClickHandler();
            }
            else {
                loadWork();
            }
        }, 200);
    }

    // UI 사용할 수 있는 상태인지 체크
    function isReady() {
        return $('.tool-button').length > 0;
    }

    // 패널 초기화
    function initPanel() {
        // 미리보기 작게
        clickPreviewMinimize();

        // 박스 아이콘 선택
        clickToolBox();
        
        // 설정 창 초기화
        initSettings();

        // 단축키 초기화
        initLabelsLegendShortcut();

        // 일괄 분류 초기화
        initLabelsBatchSelector();

        // 반려 모아보기 초기화
        initLabelsReject();
    }

    // 중간 저장 타이머 설정
    function setKeepSaveTimer() {
        $('.actions > .spacer').append('<label class="title">마지막 중간 저장:</label> <span id="KeepSaveTime">00:00:00</span>');

        setInterval(function(){           
            $('.button.keep').click();

            console.log('[autosave]', $('.timer-section').text());
        }, SaveInterval * 1000);
    }

    // 단축키 설정
    function setShortKey() {
        // 컨트롤 키 누름
        $(document).keydown(function(e) {          
            if(e.keyCode == 17) {
                clickToolMove();
            }
        });

        // 컨트롤 키 뗌
        $(document).keyup(function(e) {
            if(e.keyCode == 17) {
                clickToolBox();
            }
        });        
    }

    // 단축키 index 지정
    var legendShortcut = [
        '',
        'whiteColor',
        'orangeColor',
        'yellowColor',
        'greenColor',
        'blueColor',
        'indigoColor',
        'purpleColor'
    ];

    // 단축키 초기화
    function initLabelsLegendShortcut() {
        setTimeout(function() {
            if($('.panel-header').length > 0) {       
                $.each(legendShortcut, function(idx, item) {
                    if(idx > 0) {
                        $('.panel-header .colorCircle.' + item).text(idx);
                    }
                });
        
                $(document).keypress(function(e) {
                    if(KEYCODE_1 <= e.keyCode && e.keyCode < (KEYCODE_1 + legendShortcut.length - 1)) {
                        var idx = e.keyCode - KEYCODE_1 + 1;

                        $('.panel-header .colorCircle.' + legendShortcut[idx]).click();
                    }
                });
            }
            else {
                initLabelsLegendShortcut();
            }
        }, 100);
    }

    // 일괄 분류 초기화
    function initLabelsBatchSelector() {
        setTimeout(function() {
            if($('.tree-view').length > 0) {       
                $('.tree-view > .labels > ul').each(function() {
                    $(this).find('.name_fixed').after('<input type="checkbox">');
                });

                var isSelectorRunning = false;
                $('.tree-view > .labels > ul').on('click', '.selectList > .lists', function() {
                    if(isSelectorRunning) return;

                    if($(this).closest('.name').find('input[type=checkbox]').is(':checked')) {
                        isSelectorRunning = true;

                        var idx = $(this).index();

                        $('.tree-view > .labels > ul input[type=checkbox]:checked').each(function() {
                            var $selector = $(this).parent().find('.selector');
                            $selector.click();
                            $selector.find('.lists:eq('+idx+')').click();
    
                            $(this).prop('checked', false);
                        });

                        isSelectorRunning = false;
                    }
                });
            }
            else {
                initLabelsBatchSelector();
            }
        }, 100);
    }

    // 반려 모아보기 초기화
    function initLabelsReject() {
        setTimeout(function() {
            if($('.tree-view').length > 0) {   
                if($('.tree-view .rejectColor').length > 0) {
                    $('.tree-view .rejectColor').closest('ul').addClass('label-reject');
                    $('.panel-header-name > .title').after('<div class="label-reject">반려</div>');

                    $('.panel-header-name > .label-reject').click(function() {
                        if($(this).hasClass('labelsOn')) {
                            $('.tree-view > .labels').removeClass('only-reject');
                            $(this).removeClass('labelsOn');
                        }
                        else {
                            $(this).addClass('labelsOn');
                            $('.tree-view > .labels').addClass('only-reject');
                        }
                    });
                }
            }
            else {
                initLabelsReject();
            }
        }, 100);
    }

    // 이동 도구 아이콘 클릭
    function clickToolMove() {
        var $button = $('.tool-button:nth-child(1)');

        if(!$button.hasClass('tool-selected')) $button.click();
    }

    // 박스 도구 아이콘 클릭
    function clickToolBox() {
        var $button = $('.tool-button:nth-child(2)');
        
        if(!$button.hasClass('tool-selected')) $button.click();
    }

    // 미리보기 최소화 버튼 클릭
    function clickPreviewMinimize() {
        $('span.thumbnail-slider > img:nth-child(1)').click();
    }

    // 설정 창 초기화
    function initSettings() {
        clickSetting();

        setTimeout(function() {
            clickShowCross();

            setTimeout(function() {
                clickSetting();
            }, 100);
        }, 100);
    }

    // 도구 아이콘 클릭
    function clickSetting() {
        $('.fab-button:nth-child(1)').click();
    }

    // 중간 저장 이벤트 핸들러
    function setKeepSaveClickHandler() {
        setTimeout(function() {
            if($('.button.keep').length > 0) {
                $('.button.keep').click(function() {
                    var keepSaveTime = $('.timer-section').text();
        
                    $('#KeepSaveTime').text(keepSaveTime);            
                });    
            }
            else {
                setKeepSaveClickHandler();
            }    
        }, 200);
    }

    // 십자선 보기 클릭
    function clickShowCross() {
        $('.setting-box .v-input--switch input').click();
    }
    
    $(document).ready(function(){

        chrome.storage.sync.get(['isNavigate'], function(result) {
            if(result.isNavigate) {
                chrome.storage.sync.set({isNavigate: false});
                location.reload();
                return;
            }
            else {
                console.log('helper start')

                loadWork();
            }
        });
    });

})();