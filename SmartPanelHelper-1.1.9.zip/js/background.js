chrome.webNavigation.onHistoryStateUpdated.addListener(function(details) {
    if(details.url.startsWith('https://global-aiworks.smartpanel.kr/worklist2')) {
        chrome.storage.sync.set({isNavigate: true});
    }
});